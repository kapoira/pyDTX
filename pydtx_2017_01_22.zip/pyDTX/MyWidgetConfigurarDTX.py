# -*- coding: utf-8 -*-
import configparser

from PyQt5 import QtWidgets

from WidgetConfigurarDTX import Ui_WidgetConfigurarDTX


class MyWidgetConfigurarDTX(QtWidgets.QWidget):

    def __init__(self):
        super(MyWidgetConfigurarDTX, self).__init__()

        self.ui = Ui_WidgetConfigurarDTX()
        self.ui.setupUi(self)

        self.leer_config_dtx()

        self.ui.exitButton.pressed.connect(self.exit)
        self.ui.saveButton.pressed.connect(self.save_config_dtx)

    def exit(self):
        self.parentWidget().setCurrentIndex(0)

    def leer_config_dtx(self):
        self.config_dtx = configparser.ConfigParser()
        self.config_dtx.read('config_dtx.ini')
        if self.config_dtx['Graphics']['OpenGl'] == 'true':
            self.ui.checkBox_Gl.setChecked(True)
        else:
            self.ui.checkBox_Gl.setChecked(False)
        self.ui.theme_LineEdit.setText(self.config_dtx['Graphics']['theme'])
        self.ui.speed_SpinBox.setValue(int(self.config_dtx['DTX']['speed']))

    def save_config_dtx(self):
        self.config_dtx['DTX'] = {}
        self.config_dtx['DTX']['speed'] = str(self.ui.speed_SpinBox.value())

        theme = self.ui.theme_LineEdit.text()
        self.config_dtx['Graphics']['theme'] = theme

        if self.ui.checkBox_Gl.checkState():
            self.config_dtx['Graphics']['opengl'] = 'true'
        else:
            self.config_dtx['Graphics']['opengl'] = 'false'
        with open('config_dtx.ini', 'w') as configfile:
            self.config_dtx.write(configfile)