# -*- coding: utf-8 -*-

from LaneAuto import LaneAuto


class LaneVisual(LaneAuto):

    def __init__(self, color, posicion, tiempo_pantalla, auto):
        super(LaneVisual, self).__init__()
        self.color = color
        self.posicion = posicion
        self.tiempo_pantalla = tiempo_pantalla
        self.auto = auto

    def leer_color(self):
        return self.color

    def leer_pos(self):
        return self.posicion

    def comprobar_y_poner_hit(self, tiempo_actual):
        tiempo_menor = 10000
        nota_mas_cercana = None

        for nota in self.lista_chips:
            if not(nota.leer_hit()):
                if abs(nota.leer_tiempo() - tiempo_actual) < tiempo_menor:
                    tiempo_menor = abs(nota.leer_tiempo() - tiempo_actual)
                    nota_mas_cercana = nota
        if nota_mas_cercana:
            nota_mas_cercana.set_hit()
        return tiempo_menor

    def comprobar_tiempo(self, tiempo_actual):
        tiempo_menor = 10000
        for nota in self.lista_chips:
            if not(nota.leer_hit()):
                if abs(nota.leer_tiempo() - tiempo_actual) < tiempo_menor:
                    tiempo_menor = abs(nota.leer_tiempo() - tiempo_actual)
        return tiempo_menor