# -*- coding: utf-8 -*-


class ChipAuto():

    def __init__(self, nota, tiempo):
        self.tiempo = tiempo
        self.nota = nota

    def leer_tiempo(self):
        return self.tiempo

    def leer_nota(self):
        return self.nota