# -*- coding: utf-8 -*-

from PyQt5 import QtWidgets

from MainWindowQt5 import Ui_MainWindow


class MyMainWindowQt5(QtWidgets.QMainWindow):

    def __init__(self, theme):
        super(MyMainWindowQt5, self).__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.button_StartGame.pressed.connect(self.cambiar_a_navegacion)
        self.ui.button_ConfigureDrum.pressed.connect(self.cambiar_drum_keys)
        self.ui.button_ConfigureDTX.clicked.connect(self.cambiar_config_dtx)
        self.ui.button_Quit.clicked.connect(self.salir)

        style_sheet = "#Principal{border-image: url(" + theme + \
                       "background_menu.jpg) stretch stretch " + "; }"

        self.ui.Principal.setStyleSheet(style_sheet)

    def cambiar_a_navegacion(self):
        self.ui.stackedWidget.setCurrentIndex(1)

    def cambiar_drum_keys(self):
        self.ui.stackedWidget.setCurrentIndex(2)

    def cambiar_config_dtx(self):
        self.ui.stackedWidget.setCurrentIndex(3)

    def cambiar_menu_principal(self):
        self.ui.stackedWidget.setCurrentIndex(0)

    def cambiar_reproduccion(self):
        self.ui.stackedWidget.setCurrentIndex(4)

    def salir(self):
        self.close()
