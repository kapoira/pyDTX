# -*- coding: utf-8 -*-

from PyQt5 import QtCore
from PyQt5.QtMultimedia import QSoundEffect


class LaneAuto():

    def __init__(self):
        self.lista_chips = []
        self.mediaPlayer = QSoundEffect()
        self.banco_sonidos = {}

    def insertar_chip(self, chip):
        self.lista_chips.append(chip)

    def insertar_sonidos(self, banco_sonidos):
        self.banco_sonidos = banco_sonidos

    def reproducir(self, tiempo_actual):
        if self.lista_chips:
            nota = self.lista_chips[0]
            if nota.leer_tiempo() <= tiempo_actual:
                sonido = self.banco_sonidos[nota.leer_nota()]
                cancion = QtCore.QUrl.fromLocalFile(sonido)
                self.mediaPlayer.setSource(cancion)
                self.mediaPlayer.play()
                self.lista_chips.pop(0)