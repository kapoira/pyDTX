python3 -O ./pyDTX/main.py
