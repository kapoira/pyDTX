# -*- coding: utf-8 -*-

from PyQt5 import QtCore
from PyQt5 import QtWidgets


class Chip(QtWidgets.QGraphicsWidget):

    def __init__(self, nota, tiempo):
        super(QtWidgets.QGraphicsWidget, self).__init__()
        self.tiempo = tiempo
        self.nota = nota
        self.animacion_nota = False
        self.color = False
        self.hit = False
        self.prop = False

    def paint(self, painter, option, widget):
        painter.fillRect(self.rect(), self.color)

    def leer_tiempo(self):
        return self.tiempo

    def leer_nota(self):
        return self.nota

    def set_hit(self):
        self.hit = True

    def leer_hit(self):
        return self.hit

    def set_color(self, color):
        self.color = color

    def animar(self, posicion, tiempo):
        geometry = QtCore.QByteArray(b'geometry')
        self.prop = QtCore.QPropertyAnimation(self, geometry)
        self.prop.setDuration(tiempo)
        self.prop.setStartValue(QtCore.QRect(posicion, 0, 80, 10))
        self.prop.setEndValue(QtCore.QRect(posicion, 720, 80, 10))
        self.animacion_nota = QtCore.QParallelAnimationGroup()
        self.animacion_nota.addAnimation(self.prop)
        self.animacion_nota.start()
        return self.animacion_nota