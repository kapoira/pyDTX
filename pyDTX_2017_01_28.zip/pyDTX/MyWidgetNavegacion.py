# -*- coding: utf-8 -*-

import os
import configparser

from PyQt5 import QtWidgets
from PyQt5 import QtGui

from WidgetNavegacion import Ui_WidgetNavegacion


def es_notacion(string):
    """
        Quitando al string que nos pasa primer caracter y tres ultimos sabremos
        si es una notacion de objetos para un compas sino sera una orden
    """
    try:
        #le quitamos el # y el :
        int(string[1:-3])
        return True
    except:
        return False


def buscar_directorios_en_directorio(directorio):
    """
        Buscar directorios dentro de un path
    """

    lista_directorios = []
    for name in os.listdir(directorio):
        posible_file = os.path.join(directorio, name)
        if os.path.isdir(posible_file):
            lista_directorios.append(name)
    return lista_directorios


def buscar_info_directorio(directorio):
    """
        Buscara informacion de los posibles archivos .dtx/.def en un directorio
    """
    posible_file = os.path.join(directorio, 'set.def')
    if os.path.exists(posible_file):
        return conseguir_info_def(posible_file)
    posible_file = os.path.join(directorio, 'SET.DEF')
    if os.path.exists(posible_file):
        return conseguir_info_def(posible_file)
    posible_file = os.path.join(directorio, 'box.def')
    if os.path.exists(posible_file):
        return conseguir_info_box(posible_file)
    posible_file = os.path.join(directorio, 'BOX.DEF')
    if os.path.exists(posible_file):
        return conseguir_info_box(posible_file)
    for name in os.listdir(directorio):
        posible_file = os.path.join(directorio, name)
        if name.endswith('.dtx') or name.endswith('.DTX'):
            return conseguir_info_dtx(posible_file)
    return []


def conseguir_info_def(archivo):
    fp = open(archivo, "r")
    lista_info = [[1, 0, 0], [2, 0, 0], [3, 0, 0], [4, 0, 0], [5, 0, 0]]
    while True:
        linea = fp.readline()
        if not linea:
            break
        linea = linea.rstrip('\r\n\t')
        linea = linea.split(";")
        primer_espacio = linea[0].find(" ")
        orden = linea[0][:primer_espacio]
        if orden:
            if not(es_notacion(orden)):
                if orden == "#L1LABEL:":
                    lista_info[0][0] = linea[0][primer_espacio + 1:]
                elif orden == "#L1FILE:":
                    archivo_local = linea[0][primer_espacio + 1:]
                    path = os.path.dirname(archivo)
                    archivo_dtx = os.path.join(path, archivo_local)
                    info_dtx = conseguir_info_dtx(archivo_dtx)
                    lista_info[0][2] = info_dtx
                    lista_info[0][1] = archivo_dtx
                elif orden == "#L2LABEL:":
                    lista_info[1][0] = linea[0][primer_espacio + 1:]
                elif orden == "#L2FILE:":
                    archivo_local = linea[0][primer_espacio + 1:]
                    path = os.path.dirname(archivo)
                    archivo_dtx = os.path.join(path, archivo_local)
                    info_dtx = conseguir_info_dtx(archivo_dtx)
                    lista_info[1][2] = info_dtx
                    lista_info[1][1] = archivo_dtx
                elif orden == "#L3LABEL:":
                    lista_info[2][0] = linea[0][primer_espacio + 1:]
                elif orden == "#L3FILE:":
                    archivo_local = linea[0][primer_espacio + 1:]
                    path = os.path.dirname(archivo)
                    archivo_dtx = os.path.join(path, archivo_local)
                    info_dtx = conseguir_info_dtx(archivo_dtx)
                    lista_info[2][2] = info_dtx
                    lista_info[2][1] = archivo_dtx
                elif orden == "#L4LABEL:":
                    lista_info[3][0] = linea[0][primer_espacio + 1:]
                elif orden == "#L4FILE:":
                    archivo_local = linea[0][primer_espacio + 1:]
                    path = os.path.dirname(archivo)
                    archivo_dtx = os.path.join(path, archivo_local)
                    info_dtx = conseguir_info_dtx(archivo_dtx)
                    lista_info[3][2] = info_dtx
                    lista_info[3][1] = archivo_dtx
                elif orden == "#L5LABEL:":
                    lista_info[4][0] = linea[0][primer_espacio + 1:]
                elif orden == "#L5FILE:":
                    archivo_local = linea[0][primer_espacio + 1:]
                    path = os.path.dirname(archivo)
                    archivo_dtx = os.path.join(path, archivo_local)
                    info_dtx = conseguir_info_dtx(archivo_dtx)
                    lista_info[4][2] = info_dtx
                    lista_info[4][1] = archivo_dtx
    fp.close()
    return lista_info


def conseguir_info_box(archivo):
    fp = open(archivo, "r")
    print ("TODO analizar box")
    while True:
        linea = fp.readline()
        if not linea:
            break
    fp.close()


def conseguir_info_dtx(archivo):
    fp = open(archivo, "r")
    lista_info = [None, None, None, None]
    while True:
        linea = fp.readline()
        if not linea:
            break
        linea = linea.rstrip('\r\n')
        linea = linea.split(";")
        campos = linea[0].split(" ")
        primer_espacio = linea[0].find(" ")
        orden = linea[0][:primer_espacio]
        if orden:
            if not(es_notacion(orden)):
                if orden == "#TITLE:":
                    lista_info[1] = linea[0][primer_espacio + 1:]
                elif campos[0] == "#DLEVEL:":
                    lista_info[2] = linea[0][primer_espacio + 1:]
                elif campos[0] == "#PREIMAGE:":
                    archivo_local = linea[0][primer_espacio + 1:]
                    path = os.path.dirname(archivo)
                    archivo_imagen = os.path.join(path, archivo_local)
                    lista_info[0] = archivo_imagen
    fp.close()
    return lista_info


class MyWidgetNavegacion(QtWidgets.QWidget):

    def __init__(self):
        super(MyWidgetNavegacion, self).__init__()

        self.ui = Ui_WidgetNavegacion()
        self.ui.setupUi(self)
        self.ui.listWidget.itemSelectionChanged.connect(self.cambio_seleccion)

        #Cargamos configuracion de dtx
        config_dtx = configparser.ConfigParser()
        config_dtx.read('config_dtx.ini')

        self.path_songs = config_dtx['Songs']['path']
        self.path_songs_inicial = config_dtx['Songs']['path']

        #Conectamos los botones a sus funciones
        self.ui.downButton.clicked.connect(self.seleccion_abajo)
        self.ui.upButton.clicked.connect(self.seleccion_arriba)
        self.ui.backButton.clicked.connect(self.seleccion_back)
        self.ui.selectButton.clicked.connect(self.seleccion_select)
        self.ui.changedirButton.clicked.connect(self.seleccion_changedir)
        self.ui.l1_Button.clicked.connect(self.seleccion_select_l1)
        self.ui.l2_Button.clicked.connect(self.seleccion_select_l2)
        self.ui.l3_Button.clicked.connect(self.seleccion_select_l3)
        self.ui.l4_Button.clicked.connect(self.seleccion_select_l4)
        self.ui.l5_Button.clicked.connect(self.seleccion_select_l5)
        self.ui.speed_inc_Button.clicked.connect(self.speed_inc)
        self.ui.speed_dec_Button.clicked.connect(self.speed_dec)

        self.rehacer_lista()

        #Leemos la configuracion del dtx para tener el tiempo pantalla
        self.config_dtx = configparser.ConfigParser()
        self.config_dtx.read('config_dtx.ini')

        self.tiempo_pantalla = int(self.config_dtx['DTX']['speed'])
        self.ui.speed_label.setText(str(self.tiempo_pantalla))

    def speed_inc(self):
        if self.tiempo_pantalla > 100:
            self.tiempo_pantalla = self.tiempo_pantalla - 100
            self.ui.speed_label.setText(str(self.tiempo_pantalla))

    def speed_dec(self):
        if self.tiempo_pantalla < 5000:
            self.tiempo_pantalla = self.tiempo_pantalla + 100
            self.ui.speed_label.setText(str(self.tiempo_pantalla))

    def seleccion_abajo(self):
        if ((self.seleccionado + 1) < len(self.lista_items)):
            self.seleccionado = self.seleccionado + 1
            self.ui.listWidget.setCurrentRow(self.seleccionado)

    def seleccion_arriba(self):
        if self.seleccionado > 0:
            self.seleccionado = self.seleccionado - 1
            self.ui.listWidget.setCurrentRow(self.seleccionado)

    def seleccion_back(self):
        print (self.path_songs)
        print (self.path_songs_inicial)
        if self.path_songs == self.path_songs_inicial:
            self.parentWidget().setCurrentIndex(0)
        else:
            self.path_songs = os.path.dirname(self.path_songs)
            self.rehacer_lista()

    def cambio_seleccion(self):
        self.seleccionado = self.ui.listWidget.currentRow()
        self.imagenCancion = None
        self.ui.imagenCancion.clear()
        self.ui.label_name.setText("Author:")
        self.ui.label_dificulty.setText("Dificulty:")
        self.ui.label_others.setText("")
        self.ui.l1_Button.hide()
        self.ui.l2_Button.hide()
        self.ui.l3_Button.hide()
        self.ui.l4_Button.hide()
        self.ui.l5_Button.hide()
        self.ui.selectButton.hide()
        self.ui.changedirButton.hide()
        if len(self.lista_info_items[self.seleccionado]) == 4:
            #1 elemento
            self.ui.selectButton.show()
            self.actualizar_datos(self.lista_info_items[self.seleccionado])
        elif len(self.lista_info_items[self.seleccionado]) == 5:
            #Estamos en un set.def
            if self.lista_info_items[self.seleccionado][4][0]:
                texto = self.lista_info_items[self.seleccionado][0][0]
                self.ui.l1_Button.setText(texto)
                self.ui.l1_Button.show()
            if self.lista_info_items[self.seleccionado][3][0]:
                texto = self.lista_info_items[self.seleccionado][1][0]
                self.ui.l2_Button.setText(texto)
                self.ui.l2_Button.show()
            if self.lista_info_items[self.seleccionado][2][0]:
                texto = self.lista_info_items[self.seleccionado][2][0]
                self.ui.l3_Button.setText(texto)
                self.ui.l3_Button.show()
            if self.lista_info_items[self.seleccionado][1][0]:
                texto = self.lista_info_items[self.seleccionado][3][0]
                self.ui.l4_Button.setText(texto)
                self.ui.l4_Button.show()
            if self.lista_info_items[self.seleccionado][0][0]:
                texto = self.lista_info_items[self.seleccionado][4][0]
                self.ui.l5_Button.setText(texto)
                self.ui.l5_Button.show()
        else:
            #Directorio
            self.ui.changedirButton.show()

    def seleccion_changedir(self):
        self.path_songs = self.lista_items[self.seleccionado]
        self.rehacer_lista()

    def actualizar_datos(self, datos):
        if datos[0]:
            self.imagenCancion = QtGui.QPixmap(datos[0])
            self.ui.imagenCancion.setPixmap(self.imagenCancion)
        if datos[1]:
            self.ui.label_name.setText(datos[1])
        if datos[2]:
            self.ui.label_dificulty.setText(datos[2])
        if datos[3]:
            self.ui.label_others.setText(datos[2])

    def seleccion_select(self):
        self.parentWidget().setCurrentIndex(4)
        path = self.lista_items[self.seleccionado]
        for name in os.listdir(path):
            dtx_file = os.path.join(path, name)
            if name.endswith('.dtx') or name.endswith('.DTX'):
                widgetDTX = self.parentWidget().currentWidget()
                widgetDTX.reproducir_cancion(dtx_file, self.tiempo_pantalla)

    def seleccion_label(self, selec):
        self.parentWidget().setCurrentIndex(4)
        path = self.lista_info_items[self.seleccionado][selec][1]
        widgetDTX = self.parentWidget().currentWidget()
        widgetDTX.reproducir_cancion(path, self.tiempo_pantalla)

    def seleccion_select_l1(self):
        self.seleccion_label(0)

    def seleccion_select_l2(self):
        self.seleccion_label(1)

    def seleccion_select_l3(self):
        self.seleccion_label(2)

    def seleccion_select_l4(self):
        self.seleccion_label(3)

    def seleccion_select_l5(self):
        self.seleccion_label(4)

    def rehacer_lista(self):
        self.ui.listWidget.clear()
        self.lista_items = []
        self.lista_info_items = []
        for name in buscar_directorios_en_directorio(self.path_songs):
            self.ui.listWidget.addItem(name)
            posible_file = os.path.join(self.path_songs, name)
            self.lista_items.append(posible_file)
            self.lista_info_items.append(buscar_info_directorio(posible_file))
        self.seleccionado = 0
        if len(self.lista_items) > 0:
            self.ui.listWidget.setCurrentRow(self.seleccionado)