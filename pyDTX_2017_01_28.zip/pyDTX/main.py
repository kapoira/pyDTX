#!usr/bin/env Python3
# -*- coding: utf-8 -*-

import sys

from PyQt5 import QtWidgets

from MyMainWindowQt5 import MyMainWindowQt5
from MyWidgetNavegacion import MyWidgetNavegacion
from MyWidgetConfigurarDrum import MyWidgetConfigurarDrum
from MyWidgetConfigurarDTX import MyWidgetConfigurarDTX
from ReproductorDTX import ReproductorDTX


version = "1.0.0"

#Obligatorios TODO
#https://sites.google.com/site/fungsdtx/dtx-dan-qu-dtx-single/maroon5-thislove
#TODO Tengo 9 lanes funcionando (deberian ser 10 lanes y el hihat open cerrado)
#TODO poner los 10 lanes como tocan y colores
#TODO Limpieza de codigo y continuar documentacion


#Importantes TODO
#TODO¿? Limpiar canciones de practicas
#TODO¿? codificacion utf-8 canciones inet y cambio de .wav a .ogg
#TODO¿? Drumhat - acabar de poner todos las notas midis posibles
#TODO¿? Controlar navegacion al menos con drum-midi

#Futuros TODO
#TODO ¿?Reescalado de imagen de navegacion, imagen > 600x600
#TODO Hiscores¿?
#TODO Animacion para cuando se toca se ayuda visual para perfect,good
#TODO segundo background para las configuraciones
#TODO Analizar los .box
#TODO No analizo si en el .dtx hay doble linea para el mismo compas y lane
#TODO Boton para coger siguiente nota y configurar drum de manera sencilla


def main():
    """
     Programa principal creamos ventana principal, stacked widgets
    """

    print ("pyDTX", version, "<kapoira@gmail.com>")

    #Crear la aplicacion y cargar la configuracion de los archivos
    app = QtWidgets.QApplication(sys.argv)

    #Creamos la ventana principal
    mainWindow = MyMainWindowQt5()

    #Creamos las ventanas en stack para ya tenerlas en memoria
    ui_widgetNavegacion = MyWidgetNavegacion()
    mainWindow.ui.stackedWidget.insertWidget(1, ui_widgetNavegacion)
    ui_widgetConfigurarDrum = MyWidgetConfigurarDrum()
    mainWindow.ui.stackedWidget.insertWidget(2, ui_widgetConfigurarDrum)
    ui_widgetConfigurarDTX = MyWidgetConfigurarDTX()
    mainWindow.ui.stackedWidget.insertWidget(3, ui_widgetConfigurarDTX)
    ui_widgetReproductor = ReproductorDTX()
    mainWindow.ui.stackedWidget.insertWidget(4, ui_widgetReproductor)

    #Bucle principal
    mainWindow.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    """
    La llamada desde terminal ejecuta el codigo main()
    """
    main()