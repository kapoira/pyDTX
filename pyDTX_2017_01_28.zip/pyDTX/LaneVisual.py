# -*- coding: utf-8 -*-

from LaneAuto import LaneAuto


class LaneVisual(LaneAuto):

    def __init__(self, color, posicion, tiempo_pantalla, auto):
        super(LaneVisual, self).__init__()
        self.color = color
        self.posicion = posicion
        self.tiempo_pantalla = tiempo_pantalla
        self.tiempo_poor = self.tiempo_pantalla / 2

        self.auto = auto

    def leer_color(self):
        return self.color

    def leer_pos(self):
        return self.posicion

    def comprobar_y_poner_hit(self, tiempo_actual):
        tiempo_menor = 10000
        nota_mas_cercana = None

        for nota in self.lista_chips:
            if not(nota.leer_hit()):
                if abs(nota.leer_tiempo() - tiempo_actual) < tiempo_menor:
                    tiempo_menor = abs(nota.leer_tiempo() - tiempo_actual)
                    nota_mas_cercana = nota
        if nota_mas_cercana:
            nota_mas_cercana.set_hit()
        return tiempo_menor

    def comprobar_tiempo(self, tiempo_actual):
        tiempo_menor = 10000
        for nota in self.lista_chips:
            if not(nota.leer_hit()):
                if abs(nota.leer_tiempo() - tiempo_actual) < tiempo_menor:
                    tiempo_menor = abs(nota.leer_tiempo() - tiempo_actual)
        return tiempo_menor

    def eliminar_nota_antigua(self, tiempo_actual):
        """
        eliminar_nota_antigua
            tiempo_actual
            return true si ha eliminado nota sin hit, false de otra manera
        """
        if self.lista_chips:
            nota = self.lista_chips[0]
            tiempo_final = nota.leer_tiempo() + self.tiempo_poor
            if tiempo_actual >= tiempo_final:
                estado = nota.leer_hit()
                self.lista_chips.pop(0)
                return not(estado)
        return False
