# -*- coding: utf-8 -*-

import configparser

from PyQt5 import QtWidgets

from WidgetConfigurarDTX import Ui_WidgetConfigurarDTX


class MyWidgetConfigurarDTX(QtWidgets.QWidget):

    def __init__(self):
        super(MyWidgetConfigurarDTX, self).__init__()

        self.ui = Ui_WidgetConfigurarDTX()
        self.ui.setupUi(self)

        self.leer_config_dtx()

        self.ui.exitButton.pressed.connect(self.exit)
        self.ui.saveButton.pressed.connect(self.save_config_dtx)
        self.ui.speed_SpinBox.valueChanged.connect(self.visualizar_tiempos)

    def exit(self):
        self.parentWidget().setCurrentIndex(0)

    def leer_config_dtx(self):
        self.config_dtx = configparser.ConfigParser()
        self.config_dtx.read('config_dtx.ini')
        if self.config_dtx['Graphics']['OpenGl'] == 'true':
            self.ui.checkBox_Gl.setChecked(True)
        else:
            self.ui.checkBox_Gl.setChecked(False)
        self.ui.theme_LineEdit.setText(self.config_dtx['Graphics']['theme'])
        self.ui.songs_LineEdit.setText(self.config_dtx['Songs']['path'])
        tiempo = int(self.config_dtx['DTX']['speed'])
        self.ui.speed_SpinBox.setValue(tiempo)
        self.visualizar_tiempos(tiempo)

    def save_config_dtx(self):
        self.config_dtx['DTX'] = {}
        self.config_dtx['DTX']['speed'] = str(self.ui.speed_SpinBox.value())

        theme = self.ui.theme_LineEdit.text()
        self.config_dtx['Graphics']['theme'] = theme

        songs = self.ui.songs_LineEdit.text()
        self.config_dtx['Songs']['path'] = songs

        if self.ui.checkBox_Gl.checkState():
            self.config_dtx['Graphics']['opengl'] = 'true'
        else:
            self.config_dtx['Graphics']['opengl'] = 'false'
        with open('config_dtx.ini', 'w') as configfile:
            self.config_dtx.write(configfile)

    def visualizar_tiempos(self, tiempo):
        tiempo_limpio = str(round(tiempo / 15, 2))
        perfect = "-" + tiempo_limpio + ".." + tiempo_limpio + "ms"
        tiempo_limpio = str(round(tiempo / 10, 2))
        great = "-" + tiempo_limpio + ".." + tiempo_limpio + "ms"
        tiempo_limpio = str(round(tiempo / 5, 2))
        good = "-" + tiempo_limpio + ".." + tiempo_limpio + "ms"
        tiempo_limpio = str(round(tiempo / 2, 2))
        poor = "-" + tiempo_limpio + ".." + tiempo_limpio + "ms"

        self.ui.perfect_time_Label.setText(perfect)
        self.ui.great_time_Label.setText(great)
        self.ui.good_time_Label.setText(good)
        self.ui.poor_time_Label.setText(poor)
