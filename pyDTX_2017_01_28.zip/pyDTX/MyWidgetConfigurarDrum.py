# -*- coding: utf-8 -*-

import configparser
import rtmidi2

from PyQt5 import QtWidgets

from WidgetConfigurarDrum import Ui_WidgetConfigurarDrum


class MyWidgetConfigurarDrum(QtWidgets.QWidget):

    def __init__(self):
        super(MyWidgetConfigurarDrum, self).__init__()

        self.ui = Ui_WidgetConfigurarDrum()
        self.ui.setupUi(self)

        self.leer_config_drum()

        self.ui.exitButton.pressed.connect(self.exit)
        self.ui.saveConfigurationButton.pressed.connect(self.save_config_drum)
        self.ui.portsConnectedButton.pressed.connect(self.view_ports)

    def view_ports(self):
        """
            view_ports
            Mostramos en el text, que puertos MIDI vemos conectados.
        """
        i = 0
        text = ""
        for port in rtmidi2.get_in_ports():
            text = text + str(i) + " : " + port + "\n"
            i = i + 1
        self.ui.portsConnectedTextEdit.setPlainText(text)

    def exit(self):
        """
            exit
            Volvemos al menu principal, para ello apuntamos en el stackedwidget
            al widget principal
        """
        self.parentWidget().setCurrentIndex(0)

    def leer_lane_drum(self, lane, auto, midi1, midi2, key):
        """
            leer_lane_drum
            Coger los valores del lane según fichero config_drum.ini y ponerlos
            en las variables

        """
        if self.config_drum[lane]['auto'] == 'true':
            auto.setChecked(True)
        else:
            auto.setChecked(False)
        midi1.setValue(int(self.config_drum[lane]['midi_1']))
        midi2.setValue(int(self.config_drum[lane]['midi_2']))
        key.setText(self.config_drum[lane]['key'])

    def leer_config_drum(self):
        self.config_drum = configparser.ConfigParser()
        self.config_drum.read('config_drum.ini')
        midi_port = self.config_drum['MIDI']['midi_port']
        self.ui.portMidiSpinBox.setValue(int(midi_port))

        #Lane11
        self.leer_lane_drum('Lane_11',
                             self.ui.auto_lane11_CheckBox,
                             self.ui.midi1_lane11_SpinBox,
                             self.ui.midi2_lane11_SpinBox,
                             self.ui.key_lane_11_LineEdit)
        #Lane12
        self.leer_lane_drum('Lane_12',
                             self.ui.auto_lane12_CheckBox,
                             self.ui.midi1_lane12_SpinBox,
                             self.ui.midi2_lane12_SpinBox,
                             self.ui.key_lane_12_LineEdit)
        #Lane12
        self.leer_lane_drum('Lane_13',
                             self.ui.auto_lane13_CheckBox,
                             self.ui.midi1_lane13_SpinBox,
                             self.ui.midi2_lane13_SpinBox,
                             self.ui.key_lane_13_LineEdit)
        #Lane14
        self.leer_lane_drum('Lane_14',
                             self.ui.auto_lane14_CheckBox,
                             self.ui.midi1_lane14_SpinBox,
                             self.ui.midi2_lane14_SpinBox,
                             self.ui.key_lane_14_LineEdit)
        #Lane15
        self.leer_lane_drum('Lane_15',
                             self.ui.auto_lane15_CheckBox,
                             self.ui.midi1_lane15_SpinBox,
                             self.ui.midi2_lane15_SpinBox,
                             self.ui.key_lane_15_LineEdit)
        #Lane16
        self.leer_lane_drum('Lane_16',
                             self.ui.auto_lane16_CheckBox,
                             self.ui.midi1_lane16_SpinBox,
                             self.ui.midi2_lane16_SpinBox,
                             self.ui.key_lane_16_LineEdit)
        #Lane17
        self.leer_lane_drum('Lane_17',
                             self.ui.auto_lane17_CheckBox,
                             self.ui.midi1_lane17_SpinBox,
                             self.ui.midi2_lane17_SpinBox,
                             self.ui.key_lane_17_LineEdit)
        #Lane18
        self.leer_lane_drum('Lane_18',
                             self.ui.auto_lane18_CheckBox,
                             self.ui.midi1_lane18_SpinBox,
                             self.ui.midi2_lane18_SpinBox,
                             self.ui.key_lane_18_LineEdit)
        #Lane19
        self.leer_lane_drum('Lane_19',
                             self.ui.auto_lane19_CheckBox,
                             self.ui.midi1_lane19_SpinBox,
                             self.ui.midi2_lane19_SpinBox,
                             self.ui.key_lane_19_LineEdit)

    def guardar_lane_drum(self, lane, auto, midi1, midi2, key):
            self.config_drum[lane] = {}
            if auto:
                self.config_drum[lane]['auto'] = 'true'
            else:
                self.config_drum[lane]['auto'] = 'false'
            self.config_drum[lane]['midi_1'] = midi1
            self.config_drum[lane]['midi_2'] = midi2
            self.config_drum[lane]['key'] = key

    def save_config_drum(self):
        self.config_drum['MIDI'] = {}
        midi_port = self.ui.portMidiSpinBox.value()
        self.config_drum['MIDI']['midi_port'] = str(midi_port)

        #Lane 11
        self.guardar_lane_drum('Lane_11',
                                self.ui.auto_lane11_CheckBox.checkState(),
                                str(self.ui.midi1_lane11_SpinBox.value()),
                                str(self.ui.midi2_lane11_SpinBox.value()),
                                self.ui.key_lane_11_LineEdit.text())
        #Lane 12
        self.guardar_lane_drum('Lane_12',
                                self.ui.auto_lane12_CheckBox.checkState(),
                                str(self.ui.midi1_lane12_SpinBox.value()),
                                str(self.ui.midi2_lane12_SpinBox.value()),
                                self.ui.key_lane_12_LineEdit.text())
        #Lane 13
        self.guardar_lane_drum('Lane_13',
                                self.ui.auto_lane13_CheckBox.checkState(),
                                str(self.ui.midi1_lane13_SpinBox.value()),
                                str(self.ui.midi2_lane13_SpinBox.value()),
                                self.ui.key_lane_13_LineEdit.text())
        #Lane 14
        self.guardar_lane_drum('Lane_14',
                                self.ui.auto_lane14_CheckBox.checkState(),
                                str(self.ui.midi1_lane14_SpinBox.value()),
                                str(self.ui.midi2_lane14_SpinBox.value()),
                                self.ui.key_lane_14_LineEdit.text())
        #Lane 15
        self.guardar_lane_drum('Lane_15',
                                self.ui.auto_lane15_CheckBox.checkState(),
                                str(self.ui.midi1_lane15_SpinBox.value()),
                                str(self.ui.midi2_lane15_SpinBox.value()),
                                self.ui.key_lane_15_LineEdit.text())
        #Lane 16
        self.guardar_lane_drum('Lane_16',
                                self.ui.auto_lane16_CheckBox.checkState(),
                                str(self.ui.midi1_lane16_SpinBox.value()),
                                str(self.ui.midi2_lane16_SpinBox.value()),
                                self.ui.key_lane_16_LineEdit.text())
        #Lane 17
        self.guardar_lane_drum('Lane_17',
                                self.ui.auto_lane17_CheckBox.checkState(),
                                str(self.ui.midi1_lane17_SpinBox.value()),
                                str(self.ui.midi2_lane17_SpinBox.value()),
                                self.ui.key_lane_17_LineEdit.text())
        #Lane 18
        self.guardar_lane_drum('Lane_18',
                                self.ui.auto_lane18_CheckBox.checkState(),
                                str(self.ui.midi1_lane18_SpinBox.value()),
                                str(self.ui.midi2_lane18_SpinBox.value()),
                                self.ui.key_lane_18_LineEdit.text())
        #Lane 19
        self.guardar_lane_drum('Lane_19',
                                self.ui.auto_lane19_CheckBox.checkState(),
                                str(self.ui.midi1_lane19_SpinBox.value()),
                                str(self.ui.midi2_lane19_SpinBox.value()),
                                self.ui.key_lane_19_LineEdit.text())

        with open('config_drum.ini', 'w') as configfile:
            self.config_drum.write(configfile)